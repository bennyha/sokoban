package components;

public enum WorldObjectType {

	Baggage, FLOOR, PLAYER, WALL, TARGET
}